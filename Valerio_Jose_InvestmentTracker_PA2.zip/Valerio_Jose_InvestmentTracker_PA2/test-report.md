# PA2 Test Report & Database Explanation
**Developer:** Jose
**Course:** COP 5818 - Web Application Practice

## 1. Manual Testing Log
I successfully performed the following manual tests in the browser (http://localhost:3000):

* **Authentication:** Registered a new user (`test@test.com`). Verified that the tracker panel remained hidden until I successfully logged in with the correct password.
* **Security (CSRF):** Verified that API mutations (POST/PUT/DELETE) correctly pass the `X-CSRF-Token` header.
* **Create (Add Purchase):** Successfully added multiple purchases. Verified that invalid data (e.g., negative quantities) is rejected by the server-side `validatePurchase` function.
* **Read (History & Summary):** Verified that the UI accurately calculates the total invested and purchase count, and fetches only the purchases belonging to the logged-in user.
* **Update (Edit):** Clicked "Edit" on a purchase, changed the quantity and price, and saved it. Verified the summary totals updated immediately.
* **Delete:** Clicked "Delete" on a purchase, accepted the browser confirmation prompt, and verified the item was removed from the database and UI.
* **Logout:** Clicked "Log out" and verified the session was destroyed, UI was cleared, and the login screen returned.

## 2. Database Schema Explanation
**Primary Keys:** 
The `id` column in the `purchases` table acts as the primary key. It guarantees every row has a unique identifier, allowing the API to accurately update or delete a specific record (e.g., `PUT /api/purchases/:id`) even if two purchases share the exact same name.

**Foreign Keys:** 
The `purchases` table relies on two foreign keys: `owner_id` (linking the purchase to `users.id`) and `category_id` (linking to `categories.id`). Because `foreign_keys = ON` is enabled in SQLite, the database physically prevents a purchase from being saved if it points to a user or category that does not exist, ensuring referential integrity.

**CHECK Constraints:** 
A `CHECK` constraint acts as a database-level safety net. For example, the `CHECK(quantity >= 1)` constraint guarantees that no zero or negative quantities can be saved to the database. This acts as a final, unbreakable barrier even if application-level validation fails or is bypassed.

**SQL vs. Document NoSQL for this App:** 
A relational SQL setup is ideal for this application because users, categories, and purchases have strict structures and interconnected relationships. If we updated a category name in SQL, it instantly reflects on all joined purchases via the `JOIN` query. In a document-style NoSQL database (like MongoDB), the category name would likely be duplicated and embedded directly into every single purchase document. Changing a category name in NoSQL would require finding and updating hundreds of individual purchase documents, risking data inconsistency.