// ==========================================
// 1. DOM Elements
// ==========================================
const authForm = document.getElementById('auth-form');
const emailInput = document.getElementById('email');
const passwordInput = document.getElementById('password');
const loginBtn = document.getElementById('login-button');
const registerBtn = document.getElementById('register-button');
const logoutBtn = document.getElementById('logout-button');
const accountStatus = document.getElementById('account-status');
const trackerPanel = document.getElementById('tracker-panel');

const purchaseForm = document.getElementById('purchase-form');
const nameInput = document.getElementById('investment-name');
const qtyInput = document.getElementById('quantity');
const priceInput = document.getElementById('unit-price');
const categorySelect = document.getElementById('category');
const saveBtn = document.getElementById('save-button');
const cancelEditBtn = document.getElementById('cancel-edit');
const messageEl = document.getElementById('message');

const purchaseList = document.getElementById('purchase-list');
const totalInvestedEl = document.getElementById('total-invested');
const purchaseCountEl = document.getElementById('purchase-count');

// State tracking
let currentUser = null;
let editingId = null;

// 2. The Shared API Helper & CSRF
let csrfToken = '';

async function fetchCsrfToken() {
    try {
        const response = await fetch('/api/csrf', { credentials: 'same-origin' });
        if (response.ok) {
            const data = await response.json();
            csrfToken = data.csrfToken; 
        }
    } catch (err) {
        console.error("CSRF fetch failed", err);
    }
}

// The core helper required by Part 4
async function api(path, options = {}) {
    options.headers = options.headers || {};
    options.credentials = 'same-origin'; 
    
    if (options.method && options.method !== 'GET' && csrfToken) {
        options.headers['X-CSRF-Token'] = csrfToken;
    }
    
    if (options.body && typeof options.body === 'object') {
        options.body = JSON.stringify(options.body);
        options.headers['Content-Type'] = 'application/json';
    }

    let response;
    try {
        response = await fetch(path, options);
    } catch (err) {
        throw new Error("Connection failed. The server might be offline.");
    }

    const isJson = response.headers.get('content-type')?.includes('application/json');
    const data = isJson ? await response.json() : null;

    if (!response.ok) {
        throw new Error(data?.error || `HTTP Error ${response.status}`);
    }

    return data;
}

// 3. Authentication Flow
async function handleAuth(action) {
    messageEl.textContent = "Processing...";
    const email = emailInput.value;
    const password = passwordInput.value;
    
    try {
        if (action === 'register') {
            await api('/api/register', { method: 'POST', body: { email, password } });
            messageEl.textContent = "Registered successfully! Please log in.";
        } else if (action === 'login') {
            currentUser = await api('/api/login', { method: 'POST', body: { email, password } });
            await fetchCsrfToken(); // Get a fresh token after login regeneration
            initSessionUI();
        }
    } catch (err) {
        messageEl.textContent = err.message;
    }
}

loginBtn.addEventListener('click', (e) => { e.preventDefault(); handleAuth('login'); });
registerBtn.addEventListener('click', (e) => { e.preventDefault(); handleAuth('register'); });

logoutBtn.addEventListener('click', async () => {
    try {
        await api('/api/logout', { method: 'POST' });
        currentUser = null;
        csrfToken = '';
        
        // Clear private UI data (Part 4 requirement)
        trackerPanel.hidden = true;
        authForm.hidden = false;
        accountStatus.textContent = '';
        messageEl.textContent = "Logged out successfully.";
        purchaseList.innerHTML = '';
        totalInvestedEl.textContent = "$0.00";
        purchaseCountEl.textContent = "0";
        purchaseForm.reset();
    } catch (err) {
        messageEl.textContent = err.message;
    }
});

// Check if user is already logged in on page load
async function checkLogin() {
    await fetchCsrfToken();
    try {
        currentUser = await api('/api/me');
        initSessionUI();
    } catch {
        // Not logged in, which is fine on initial load
        trackerPanel.hidden = true;
    }
}

async function initSessionUI() {
    authForm.hidden = true;
    trackerPanel.hidden = false;
    accountStatus.textContent = `Logged in as: ${currentUser.email}`;
    messageEl.textContent = "";
    
    await loadCategories();
    await loadPurchases();
}

// 4. Data Loading & UI Rendering
async function loadCategories() {
    try {
        const categories = await api('/api/categories');
        categorySelect.innerHTML = '<option value="" disabled selected>Select a category</option>';
        categories.forEach(cat => {
            const opt = document.createElement('option');
            opt.value = cat.id;
            opt.textContent = cat.name; // textContent prevents XSS
            categorySelect.appendChild(opt);
        });
    } catch (err) {
        messageEl.textContent = err.message;
    }
}

async function loadPurchases() {
    try {
        const purchases = await api('/api/purchases');
        renderPurchases(purchases);
        updateSummary(purchases);
    } catch (err) {
        messageEl.textContent = err.message;
    }
}

function updateSummary(purchases) {
    const totalCents = purchases.reduce((sum, p) => sum + p.costCents, 0);
    totalInvestedEl.textContent = `$${(totalCents / 100).toFixed(2)}`;
    purchaseCountEl.textContent = purchases.length;
}

function renderPurchases(purchases) {
    purchaseList.innerHTML = '';
    purchases.forEach(p => {
        const li = document.createElement('li');
        li.className = 'purchase-item'; // Uses your PA1 CSS

        // Safe display using textContent
        const textSpan = document.createElement('span');
        textSpan.textContent = `${p.name} - ${p.quantity} units @ $${(p.unitPriceCents / 100).toFixed(2)} (${p.categoryName}) | Total: $${(p.costCents / 100).toFixed(2)}`;
        
        const editBtn = document.createElement('button');
        editBtn.textContent = 'Edit';
        editBtn.onclick = () => startEdit(p);
        
        const delBtn = document.createElement('button');
        delBtn.textContent = 'Delete';
        delBtn.onclick = () => deletePurchase(p.id);

        li.append(textSpan, editBtn, delBtn);
        purchaseList.appendChild(li);
    });
}

// 5. CRUD Operations (Create, Update, Delete)
purchaseForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    messageEl.textContent = "Saving...";
    saveBtn.disabled = true; // Disable while pending
    
    const payload = {
        name: nameInput.value,
        quantity: parseInt(qtyInput.value, 10),
        unitPrice: parseFloat(priceInput.value),
        categoryId: parseInt(categorySelect.value, 10)
    };

    try {
        if (editingId) {
            await api(`/api/purchases/${editingId}`, { method: 'PUT', body: payload });
            messageEl.textContent = "Purchase updated.";
        } else {
            await api('/api/purchases', { method: 'POST', body: payload });
            messageEl.textContent = "Purchase added.";
        }
        
        cancelEdit(); // Resets form
        await loadPurchases(); // Reload authoritative list
    } catch (err) {
        messageEl.textContent = err.message;
    } finally {
        saveBtn.disabled = false; // Restore button
    }
});

function startEdit(purchase) {
    editingId = purchase.id;
    nameInput.value = purchase.name;
    qtyInput.value = purchase.quantity;
    priceInput.value = (purchase.unitPriceCents / 100).toFixed(2);
    categorySelect.value = purchase.categoryId;
    
    saveBtn.textContent = "Update Purchase";
    cancelEditBtn.style.display = 'inline-block';
}

function cancelEdit() {
    editingId = null;
    purchaseForm.reset();
    saveBtn.textContent = "Add Purchase";
    cancelEditBtn.style.display = 'none';
    messageEl.textContent = "";
}

cancelEditBtn.addEventListener('click', cancelEdit);

async function deletePurchase(id) {
    if (!confirm("Are you sure you want to delete this purchase?")) return;
    
    try {
        await api(`/api/purchases/${id}`, { method: 'DELETE' });
        messageEl.textContent = "Purchase deleted.";
        await loadPurchases();
    } catch (err) {
        messageEl.textContent = err.message;
    }
}

// Initialize on load
cancelEditBtn.style.display = 'none';
checkLogin();