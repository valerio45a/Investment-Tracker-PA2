function validatePurchase(body, validCategoryIds) {
    // Reject arrays, nulls, or non-object bodies
    if (!body || typeof body !== 'object' || Array.isArray(body)) {
        return { error: "Request body must be a JSON object." };
    }

    let { name, quantity, unitPrice, categoryId } = body;

    // 1. Validate Name
    if (typeof name !== 'string') return { error: "Name must be a string." };
    name = name.trim();
    if (name.length < 1 || name.length > 100) return { error: "Name must be 1-100 characters." };

    // 2. Validate Quantity
    if (typeof quantity !== 'number' || !Number.isInteger(quantity) || quantity < 1 || quantity > 10000) {
        return { error: "Quantity must be an integer between 1 and 10,000." };
    }

    // 3. Validate Category
    if (typeof categoryId !== 'number' || !Number.isInteger(categoryId) || !validCategoryIds.includes(categoryId)) {
        return { error: "Category ID is invalid or missing." };
    }

    // 4. Validate Price (Checking bounds, NaN, Infinity, and types)
    if (typeof unitPrice !== 'number' || !Number.isFinite(unitPrice)) {
        return { error: "Price must be a valid finite number." };
    }
    if (unitPrice < 0.01 || unitPrice > 1000000) {
        return { error: "Price must be between $0.01 and $1,000,000." };
    }
    
    // Convert to cents and enforce the cent step (no fractional cents)
    const unitPriceCents = Math.round(unitPrice * 100);
    if (Math.abs((unitPriceCents / 100) - unitPrice) > 0.001) {
        return { error: "Price cannot have fractions of a cent." };
    }

    // Return the sanitized data exactly as the API contract requires
    return {
        value: {
            name,
            quantity,
            unitPriceCents,
            categoryId
        }
    };
}

module.exports = { validatePurchase };