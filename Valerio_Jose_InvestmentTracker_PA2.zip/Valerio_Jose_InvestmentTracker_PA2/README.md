# Investment Purchase Tracker PA2

Student name and ID: Jose Valerio, jo509091 

## Setup
1. Install the class-supported Node.js and npm.
2. Run `npm install express better-sqlite3 express-session argon2 dotenv`.
3. Copy `.env.example` to `.env`; set a new random SESSION_SECRET (at least 32 characters).
4. Run `npm start`; visit http://localhost:3000.
5. Run `npm test` after implementing validation. Initial test failure is expected.

The schema is initialized at startup. Use only fictional accounts and purchases.
Complete the explanations requested in START_HERE.html, list known limitations,
and include your Git repository URL or git-log.txt. Add the Node version you tested.

Do not submit .env, database files, node_modules, or .git.

## github Repository URL
https://github.com/valerio45a/Investment-Tracker-PA2.git

## GenAI Use Disclosure
In accordance with the course GenAI policy, I am disclosing the use of an AI language model (Google Gemini) during the development of this assignment. I have manually reviewed, tested, and verified the accuracy of all code submitted, taking full responsibility for its veracity.

**Where and How GenAI was used:**
* **Environment Setup:** Used to troubleshoot Windows PowerShell execution policy errors (`PSSecurityException`) when running `npm install` and setting up Node.js.
* **Backend (`server.js` & `validation.js`):** Used as a pair-programming guide to implement Argon2 password hashing, structure the SQLite `JOIN` queries, and write the strict server-side `typeof` and `Number.isFinite()` validation rules.
* **Frontend (`public/script.js`):** Used to debug a `403 CSRF token rejected` error by identifying a mismatch between the JSON response key (`data.csrfToken`) and the required fetch header (`X-CSRF-Token`).

**Citations for AI-Generated Assistance:**

"Gemini. Accessed 2026-11-08. Prompt: 'I ran the code you gave me in the terminal, and got this error: npm : The term 'npm' is not recognized as the name of a cmdlet, function, script file, or operable program.' Generated using Gemini."

"Gemini. Accessed 2026-11-08. Prompt: 'I entered test@test.com and used 12345678 as the password, but I still got this same message: CSRF token rejected' Generated using Gemini."

"Gemini. Accessed 2026-11-08. Prompt: 'Here is the code within the server.js for Step 2. Where do I paste the code you provided?' Generated using Gemini."