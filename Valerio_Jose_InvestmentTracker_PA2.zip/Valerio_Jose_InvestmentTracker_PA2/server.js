require('dotenv').config();
const express = require('express');
const Database = require('better-sqlite3');
const argon2 = require('argon2');
const fs = require('node:fs');
const path = require('node:path');
const {configureSecurity,requireAuth} = require('./security');
const {validatePurchase} = require('./validation');
const app=express();
const db=new Database(path.join(__dirname,'tracker.db'));
db.pragma('foreign_keys = ON');
db.exec(fs.readFileSync(path.join(__dirname,'schema.sql'),'utf8'));
app.use(express.json({limit:'16kb'}));
configureSecurity(app);
const asyncRoute = fn => (req,res,next) => Promise.resolve(fn(req,res,next)).catch(next);
const todo = res => res.status(501).json({error:'Complete this numbered step'});

// S1: Implement GET /api/health -> {ok:true}.
app.get('/api/health', (req, res) => {
    res.json({ "ok": true });
});

// S2: Validate credentials. Normalize only email. Query duplicate email safely.
app.post('/api/register', asyncRoute(async (req, res) => {
    let { email, password } = req.body;
    
    // Basic field validation
    if (!email || typeof email !== 'string' || !password || typeof password !== 'string') {
        return res.status(400).json({ error: 'Invalid fields' });
    }
    
    email = email.trim().toLowerCase();
    if (email.length < 3 || email.length > 254 || !/\S+@\S+\.\S+/.test(email)) {
        return res.status(400).json({ error: 'Invalid email format' });
    }
    if (password.length < 8 || password.length > 128) {
        return res.status(400).json({ error: 'Password must be 8-128 characters' });
    }

    try {
        const hash = await argon2.hash(password, { type: argon2.argon2id });
        const insertStmt = db.prepare('INSERT INTO users (email, password_hash) VALUES (?, ?)');
        const result = insertStmt.run(email, hash);
        // Return 201 Created without logging the user in automatically
        res.status(201).json({ id: result.lastInsertRowid, email });
    } catch (err) {
        if (err.code === 'SQLITE_CONSTRAINT_UNIQUE') {
            return res.status(409).json({ error: 'Email already exists' });
        }
        throw err; // Let the global error handler catch other unexpected errors
    }
}));

// S3: SELECT by normalized email; await argon2.verify(storedHash,password).
app.post('/api/login', asyncRoute(async (req, res) => {
    let { email, password } = req.body;
    if (!email || typeof email !== 'string' || !password) {
        return res.status(401).json({ error: 'Invalid credentials' });
    }
    
    email = email.trim().toLowerCase();
    const user = db.prepare('SELECT id, email, password_hash FROM users WHERE email = ?').get(email);
    
    // Generic 401 response so attackers don't know if the email or password was wrong
    if (!user || !(await argon2.verify(user.password_hash, password))) {
        return res.status(401).json({ error: 'Invalid credentials' });
    }

    // Regenerate session to prevent session fixation attacks
    await new Promise((resolve, reject) => req.session.regenerate(e => e ? reject(e) : resolve()));
    req.session.userId = user.id;
    await new Promise((resolve, reject) => req.session.save(e => e ? reject(e) : resolve()));
    
    res.json({ id: user.id, email: user.email });
}));

// S4: Return only the session user's {id,email}.
app.get('/api/me', requireAuth, (req, res) => {
    const user = db.prepare('SELECT id, email FROM users WHERE id = ?').get(req.session.userId);
    res.json({ id: user.id, email: user.email });
});

// S5: destroy session; forward an error if needed; clear sid with path '/'; return {ok:true}.
app.post('/api/logout', requireAuth, (req, res, next) => {
    req.session.destroy(err => {
        if (err) return next(err);
        res.clearCookie('connect.sid', { path: '/' });
        res.json({ ok: true });
    });
});
app.get('/api/categories', requireAuth, (req, res) => {
    // S6: SELECT id,name FROM categories ORDER BY id, using all().
    const categories = db.prepare('SELECT id, name FROM categories ORDER BY id').all();
    res.json(categories);
});

// S7 & S8: Write a reusable SELECT with JOIN purchases to categories
app.get('/api/purchases', requireAuth, (req, res) => {
    const stmt = db.prepare(`
        SELECT 
            p.id, p.name, p.quantity, p.unit_price_cents AS unitPriceCents, 
            p.category_id AS categoryId, c.name AS categoryName, 
            (p.quantity * p.unit_price_cents) AS costCents
        FROM purchases p
        JOIN categories c ON p.category_id = c.id
        WHERE p.owner_id = ?
        ORDER BY p.id ASC
    `);
    const purchases = stmt.all(req.session.userId);
    res.json(purchases);
});

app.post('/api/purchases', requireAuth, (req, res) => {
    // S9: read category IDs, validatePurchase, INSERT with req.session.userId.
    const validCategoryIds = db.prepare('SELECT id FROM categories').all().map(c => c.id);
    const validated = validatePurchase(req.body, validCategoryIds);
    
    if (validated.error) {
        return res.status(400).json({ error: validated.error });
    }

    const { name, quantity, unitPriceCents, categoryId } = validated.value;
    const insertStmt = db.prepare(`
        INSERT INTO purchases (name, quantity, unit_price_cents, category_id, owner_id)
        VALUES (?, ?, ?, ?, ?)
    `);
    const result = insertStmt.run(name, quantity, unitPriceCents, categoryId, req.session.userId);

    // Fetch the newly created record to return it
    const selectStmt = db.prepare(`
        SELECT p.id, p.name, p.quantity, p.unit_price_cents AS unitPriceCents, 
               p.category_id AS categoryId, c.name AS categoryName, 
               (p.quantity * p.unit_price_cents) AS costCents
        FROM purchases p
        JOIN categories c ON p.category_id = c.id
        WHERE p.id = ? AND p.owner_id = ?
    `);
    const newPurchase = selectStmt.get(result.lastInsertRowid, req.session.userId);
    res.status(201).json(newPurchase);
});

app.put('/api/purchases/:id', requireAuth, (req, res) => {
    // S10: validate positive integer path ID; lookup using ID AND owner_id.
    const id = parseInt(req.params.id, 10);
    if (!Number.isInteger(id) || id < 1) {
        return res.status(400).json({ error: 'Invalid ID format' });
    }

    const validCategoryIds = db.prepare('SELECT id FROM categories').all().map(c => c.id);
    const validated = validatePurchase(req.body, validCategoryIds);
    
    if (validated.error) {
        return res.status(400).json({ error: validated.error });
    }

    const { name, quantity, unitPriceCents, categoryId } = validated.value;
    const updateStmt = db.prepare(`
        UPDATE purchases 
        SET name = ?, quantity = ?, unit_price_cents = ?, category_id = ?
        WHERE id = ? AND owner_id = ?
    `);
    const result = updateStmt.run(name, quantity, unitPriceCents, categoryId, id, req.session.userId);

    if (result.changes === 0) {
        return res.status(404).json({ error: 'Purchase not found or access denied' });
    }

    // Fetch and return the updated record
    const selectStmt = db.prepare(`
        SELECT p.id, p.name, p.quantity, p.unit_price_cents AS unitPriceCents, 
               p.category_id AS categoryId, c.name AS categoryName, 
               (p.quantity * p.unit_price_cents) AS costCents
        FROM purchases p
        JOIN categories c ON p.category_id = c.id
        WHERE p.id = ? AND p.owner_id = ?
    `);
    const updatedPurchase = selectStmt.get(id, req.session.userId);
    res.json(updatedPurchase);
});

app.delete('/api/purchases/:id', requireAuth, (req, res) => {
    // S11: validate path ID; DELETE WHERE id=? AND owner_id=?.
    const id = parseInt(req.params.id, 10);
    if (!Number.isInteger(id) || id < 1) {
        return res.status(400).json({ error: 'Invalid ID format' });
    }

    const deleteStmt = db.prepare('DELETE FROM purchases WHERE id = ? AND owner_id = ?');
    const result = deleteStmt.run(id, req.session.userId);

    if (result.changes === 0) {
        return res.status(404).json({ error: 'Purchase not found or access denied' });
    }

    res.json({ ok: true });
});

app.use('/api',(req,res)=>res.status(404).json({error:'API route not found'}));
app.use(express.static(path.join(__dirname,'public')));
app.use((err,req,res,next)=> {
  if (err.type==='entity.parse.failed') return res.status(400).json({error:'Invalid JSON'});
  if (err.type==='entity.too.large') return res.status(413).json({error:'Request too large'});
  console.error('Request failed');
  res.status(500).json({error:'Internal server error'});
});
app.listen(Number(process.env.PORT)||3000,()=>console.log('Open http://localhost:3000'));
